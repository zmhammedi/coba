# -*- coding: utf-8 -*-
"""Python interfaces for VW"""

from .version import __version__
